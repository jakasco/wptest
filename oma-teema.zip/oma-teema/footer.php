
 <footer class="tummansininen"> footer </footer>
</div>
<?php wp_footer(); ?> 
</body>
</html>