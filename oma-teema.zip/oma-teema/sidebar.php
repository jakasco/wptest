<?php
wp_nav_menu(array('container' => 'nav', 'container_class' => 'left-nav')); /* muuttaa menun divistä -> naviksi */
?>